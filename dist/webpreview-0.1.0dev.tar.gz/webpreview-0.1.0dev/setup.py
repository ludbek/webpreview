from setuptools import setup, find_packages
import sys, os

version = '0.1.0'

setup(name='webpreview',
      version=version,
      description="Extracts OpenGraph, TwitterCard and Schema properties from a webpage.",
      long_description=open('README.txt').read(),
      classifiers=[], # Get strings from http://pypi.python.org/pypi?%3Aaction=list_classifiers
      keywords='OpenGraph TwitterCard Schema Facebook Twitter Google+',
      author='ludbek',
      author_email='sth.srn@gmail.com',
      url='',
      license='LICENSE.txt',
      packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
      include_package_data=True,
      zip_safe=True,
      install_requires=[
          "requests==2.2.1",
	  "beautifulsoup4==4.3.2",
      ],
      entry_points="""
      # -*- Entry points: -*-
      """,
      )
